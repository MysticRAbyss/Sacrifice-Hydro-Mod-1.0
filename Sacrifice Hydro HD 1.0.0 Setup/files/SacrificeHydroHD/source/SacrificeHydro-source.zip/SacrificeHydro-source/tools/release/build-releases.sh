#!/bin/bash
# Builds the three releases with the new setup (tools/setup2) into release2/out
set -e
R=/home/claude/hydro/release2; S=/home/claude/hydro/tools/setup2; OUT=$R/out
export GOPROXY=direct GOSUMDB=off GOFLAGS=-mod=mod
rm -rf $OUT; mkdir -p $OUT
GOOLE=~/go/pkg/mod/github.com/go-ole/go-ole@v1.3.0/LICENSE
build_setup() { # edition-json title version exe-name
  cp "$1" $S/edition.json
  python3 $S/mkver.py "$2" "$3" "$2 setup" "$4" $S/vi.json $S/hydro.ico $S/setup.manifest
  /home/claude/hydro/tools/verinfo/verinfo $S/vi.json $S/rsrc_windows_amd64.syso >/dev/null
  (cd $S && GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-H windowsgui" -o "$5" .)
}
zipdir() { (cd "$1" && rm -f "$3" && zip -qr -X "$3" "$2"); }

# --- Sacrifice HD 1.1.1 (files already staged in stage/hd/files) ---
V=1.1.1; T="Sacrifice HD"; D="$OUT/Sacrifice HD $V"; mkdir -p "$D"
W=$R/work/sachd; rm -rf $W; mkdir -p "$W/$T $V Setup" "$W/SacrificeHD-$V-Manual"
cp -r $R/stage/hd/files "$W/$T $V Setup/files"
cp -r $R/stage/hd/files/. "$W/SacrificeHD-$V-Manual/"
SZ=$(du -sk $R/stage/hd/files | cut -f1); sed "s/}\s*$/,\"sizeKB\":$SZ}/" $S/editions/sachd.json > /tmp/ed.json
build_setup /tmp/ed.json "$T" $V "Install Sacrifice HD.exe" "$W/$T $V Setup/Install Sacrifice HD.exe"
cp "$W/$T $V Setup/Install Sacrifice HD.exe" "$W/$T $V Setup/files/SacrificeHD/Uninstall Sacrifice HD.exe"
cp $R/stage/hd/files/SacrificeHD/README.txt "$W/$T $V Setup/README.txt"; cp $R/stage/hd/files/SacrificeHD/README.txt "$D/README.txt"
zipdir $W "$T $V Setup" "$D/SacrificeHD-$V-Setup.zip"; zipdir $W "SacrificeHD-$V-Manual" "$D/SacrificeHD-$V-Manual.zip"

# --- Sacrifice Hydro / Hydro HD 1.0.0 ---
for E in plain hd; do
  if [ $E = hd ]; then P=SacrificeHydroHD; T="Sacrifice Hydro HD"; J=hydrohd; else P=SacrificeHydro; T="Sacrifice Hydro"; J=hydro; fi
  V=1.0.0; D="$OUT/$T $V"; mkdir -p "$D"; W=$R/work/$E; rm -rf $W; mkdir -p "$W/$T $V Setup/files" "$W/manual"
  cp -r /home/claude/hydro/pkg/$P "$W/$T $V Setup/files/$P"; F="$W/$T $V Setup/files/$P"
  rm -f "$F"/*.bat "$F/Uninstall.exe" "$F/install-manifest.txt"; cp $GOOLE "$F/licenses/go-ole-MIT.txt"
  python3 /home/claude/hydro/release/make_readme.py $E $V "$F/README.txt"
  cp -r "$F" "$W/manual/$P"
  SZ=$(du -sk "$F" | cut -f1); sed "s/}\s*$/,\"sizeKB\":$SZ}/" $S/editions/$J.json > /tmp/ed.json
  build_setup /tmp/ed.json "$T" $V "Install $T.exe" "$W/$T $V Setup/Install $T.exe"
  cp "$W/$T $V Setup/Install $T.exe" "$F/Uninstall $T.exe"
  cp "$F/README.txt" "$W/$T $V Setup/README.txt"; cp "$F/README.txt" "$D/README.txt"
  zipdir $W "$T $V Setup" "$D/$P-$V-Setup.zip"; zipdir "$W/manual" "$P" "$D/$P-$V-Manual.zip"
done
cp $S/editions/hydro.json $S/edition.json
ls -laR $OUT | grep -v "^total"
