package main

// Sacrifice: Hydro setup - the parts that do not need Windows (so they can be tested anywhere):
// which edition this is, finding and checking the Sacrifice folder, unpacking the mod and
// removing it again.

import (
	"archive/zip"
	"bufio"
	_ "embed"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

//go:embed edition.json
var editionJSON []byte

type editionInfo struct {
	ID      string `json:"id"`      // registry key / identity, e.g. "SacrificeHydroHD"
	Title   string `json:"title"`   // "Sacrifice Hydro HD"
	Version string `json:"version"` // "1.0.0"
	Folder  string `json:"folder"`  // folder created inside the Sacrifice folder
	Size    int    `json:"sizeKB"`  // installed size, for Apps & features
}

var edition = func() editionInfo {
	var e editionInfo
	if err := json.Unmarshal(editionJSON, &e); err != nil {
		panic(err)
	}
	return e
}()

const launcherExe = "Sacrifice Hydro Launcher.exe"
const uninstallExe = "Uninstall.exe"
const manifestFile = "install-manifest.txt"

// userFiles are kept when the mod is updated (the player's settings); saves are never in the package
var userFiles = map[string]bool{"settings.txt": true, "hotkeys.txt": true, "launcher.ini": true}

// originalGameFiles are files of the original Sacrifice that the mod cannot run without
var originalGameFiles = []string{
	"data/menus.wad", "data/main.wad", "data/models.wad", "data/spells.wad", "data/sounds.wad",
	"data/saxs.wad", "data/interfac.wad",
}

// missingGameFiles lists the original game's files that are not in folder (none: it is a Sacrifice folder)
func missingGameFiles(folder string) []string {
	if folder == "" {
		return []string{"(no folder)"}
	}
	var missing []string
	for _, f := range originalGameFiles {
		if st, err := os.Stat(filepath.Join(folder, filepath.FromSlash(f))); err != nil || st.Size() == 0 {
			missing = append(missing, f)
		}
	}
	if st, err := os.Stat(filepath.Join(folder, "maps")); err != nil || !st.IsDir() {
		missing = append(missing, "maps")
	}
	return missing
}

// normalizeGameFolder accepts the Sacrifice folder, its data folder, or a folder inside it (e.g. an
// older copy of the mod) and returns the Sacrifice folder
func normalizeGameFolder(p string) string {
	p = filepath.Clean(strings.Trim(strings.TrimSpace(p), `"`))
	for i := 0; i < 3 && p != "" && p != "." && p != filepath.Dir(p); i++ {
		if len(missingGameFiles(p)) == 0 {
			return p
		}
		p = filepath.Dir(p)
	}
	return ""
}

// findGameFolder returns the first candidate that is a Sacrifice folder
func findGameFolder(candidates []string) string {
	seen := map[string]bool{}
	for _, c := range candidates {
		if c == "" || seen[strings.ToLower(c)] {
			continue
		}
		seen[strings.ToLower(c)] = true
		if f := normalizeGameFolder(c); f != "" {
			return f
		}
	}
	return ""
}

// commonGameFolders are the usual places of the GOG and Steam versions (and of old CD installs)
func commonGameFolders(drives []string) []string {
	var l []string
	for _, d := range drives {
		for _, p := range []string{
			`GOG Games\Sacrifice`, `Program Files (x86)\GOG Galaxy\Games\Sacrifice`, `Program Files (x86)\GOG.com\Sacrifice`,
			`Program Files (x86)\Steam\steamapps\common\Sacrifice`, `Program Files\Steam\steamapps\common\Sacrifice`,
			`SteamLibrary\steamapps\common\Sacrifice`, `Steam\steamapps\common\Sacrifice`,
			`Games\Sacrifice`, `Games\GOG\Sacrifice`, `Sacrifice`,
			`Program Files (x86)\Interplay\Sacrifice`, `Program Files (x86)\Shiny\Sacrifice`, `Program Files\Interplay\Sacrifice`,
		} {
			l = append(l, d+`:\`+p)
		}
	}
	return l
}

// steamLibraryFolders reads Steam's libraryfolders.vdf ("path" entries) and returns where Sacrifice would be
func steamLibraryFolders(steamPath string) []string {
	var l []string
	if steamPath == "" {
		return l
	}
	l = append(l, filepath.Join(steamPath, "steamapps", "common", "Sacrifice"))
	f, err := os.Open(filepath.Join(steamPath, "steamapps", "libraryfolders.vdf"))
	if err != nil {
		return l
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		fields := strings.Split(sc.Text(), `"`)
		// "path"		"D:\\SteamLibrary"   or (old format) "1"  "D:\\SteamLibrary"
		var vals []string
		for i := 1; i < len(fields); i += 2 {
			vals = append(vals, fields[i])
		}
		if len(vals) == 2 && (vals[0] == "path" || isDigits(vals[0])) && strings.Contains(vals[1], `:`) {
			lib := strings.ReplaceAll(vals[1], `\\`, `\`)
			l = append(l, filepath.Join(lib, "steamapps", "common", "Sacrifice"))
		}
	}
	return l
}

func isDigits(s string) bool {
	if s == "" {
		return false
	}
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

// installFiles unpacks the package into gameFolder\<edition folder>. The zip's entries start with the
// edition folder. The player's own settings are kept when they already exist. It returns the list
// of installed files (relative to the install folder) for the uninstaller.
func installFiles(payload []byte, gameFolder string, progress func(done, total int)) ([]string, error) {
	r, err := zip.NewReader(bytesReaderAt(payload), int64(len(payload)))
	if err != nil {
		return nil, fmt.Errorf("the setup is damaged (%v); please download it again", err)
	}
	target := filepath.Join(gameFolder, edition.Folder)
	prefix := edition.Folder + "/"
	var installed []string
	total := len(r.File)
	for i, f := range r.File {
		if progress != nil {
			progress(i, total)
		}
		name := f.Name
		if !strings.HasPrefix(name, prefix) {
			continue
		}
		rel := strings.TrimPrefix(name, prefix)
		if rel == "" || strings.Contains(rel, "..") {
			continue
		}
		dst := filepath.Join(target, filepath.FromSlash(rel))
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(dst, 0755); err != nil {
				return installed, err
			}
			continue
		}
		if userFiles[rel] {
			if _, err := os.Stat(dst); err == nil {
				continue // keep the player's settings
			}
		}
		if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
			return installed, err
		}
		if err := extractFile(f, dst); err != nil {
			return installed, err
		}
		if !userFiles[rel] {
			installed = append(installed, filepath.FromSlash(rel))
		}
	}
	if progress != nil {
		progress(total, total)
	}
	return installed, nil
}

func extractFile(f *zip.File, dst string) error {
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	tmp := dst + ".new"
	out, err := os.Create(tmp)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, rc); err != nil {
		out.Close()
		os.Remove(tmp)
		return err
	}
	if err := out.Close(); err != nil {
		os.Remove(tmp)
		return err
	}
	os.Remove(dst) // Windows: rename does not replace
	if err := os.Rename(tmp, dst); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}

func writeManifest(installDir string, files []string) error {
	files = append(files, uninstallExe, manifestFile)
	sort.Strings(files)
	return os.WriteFile(filepath.Join(installDir, manifestFile), []byte(strings.Join(files, "\r\n")+"\r\n"), 0644)
}

// removeFiles deletes what the setup installed. With everything, the player's settings and saved
// games go too (the whole folder). Files in use are reported.
func removeFiles(installDir string, everything bool) []string {
	var failed []string
	b, _ := os.ReadFile(filepath.Join(installDir, manifestFile))
	for _, l := range strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n") {
		l = strings.TrimSpace(l)
		if l == "" || strings.Contains(l, "..") || l == uninstallExe {
			continue
		}
		p := filepath.Join(installDir, l)
		if err := os.Remove(p); err != nil && !os.IsNotExist(err) {
			failed = append(failed, l)
		}
	}
	if everything {
		for f := range userFiles {
			os.Remove(filepath.Join(installDir, f))
		}
		os.RemoveAll(filepath.Join(installDir, "saves"))
	}
	removeEmptyDirs(installDir)
	return failed
}

// removeEmptyDirs removes the empty folders below dir (dir itself stays, the uninstaller is in it)
func removeEmptyDirs(dir string) {
	var dirs []string
	filepath.Walk(dir, func(p string, info os.FileInfo, err error) error {
		if err == nil && info.IsDir() && p != dir {
			dirs = append(dirs, p)
		}
		return nil
	})
	sort.Slice(dirs, func(i, j int) bool { return len(dirs[i]) > len(dirs[j]) })
	for _, d := range dirs {
		os.Remove(d) // fails (and stays) if not empty
	}
}

type byteReaderAt []byte

func (b byteReaderAt) ReadAt(p []byte, off int64) (int, error) {
	if off >= int64(len(b)) {
		return 0, io.EOF
	}
	n := copy(p, b[off:])
	if n < len(p) {
		return n, io.EOF
	}
	return n, nil
}

func bytesReaderAt(b []byte) io.ReaderAt { return byteReaderAt(b) }
