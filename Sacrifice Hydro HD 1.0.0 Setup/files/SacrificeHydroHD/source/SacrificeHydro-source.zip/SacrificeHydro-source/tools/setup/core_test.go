package main

import (
	"archive/zip"
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func mkzip(t *testing.T, files map[string]string) []byte {
	var b bytes.Buffer
	w := zip.NewWriter(&b)
	for n, c := range files {
		f, _ := w.Create(n)
		f.Write([]byte(c))
	}
	w.Close()
	return b.Bytes()
}

func fakeGame(t *testing.T) string {
	g := t.TempDir()
	os.MkdirAll(filepath.Join(g, "data"), 0755)
	os.MkdirAll(filepath.Join(g, "maps"), 0755)
	for _, f := range originalGameFiles {
		os.WriteFile(filepath.Join(g, filepath.FromSlash(f)), []byte("x"), 0644)
	}
	return g
}

func TestFolders(t *testing.T) {
	g := fakeGame(t)
	if len(missingGameFiles(g)) != 0 {
		t.Fatal("missing")
	}
	if normalizeGameFolder(filepath.Join(g, "data")) != g || normalizeGameFolder(filepath.Join(g, "SacrificeHydro", "x")) != g {
		t.Fatal("normalize")
	}
	if normalizeGameFolder(t.TempDir()) != "" {
		t.Fatal("not a game")
	}
	if findGameFolder([]string{"", "/nonexistent", g}) != g {
		t.Fatal("find")
	}
	os.Remove(filepath.Join(g, "data", "menus.wad"))
	if len(missingGameFiles(g)) != 1 {
		t.Fatal("menus.wad")
	}
}

func TestSteamVDF(t *testing.T) {
	s := t.TempDir()
	os.MkdirAll(filepath.Join(s, "steamapps"), 0755)
	os.WriteFile(filepath.Join(s, "steamapps", "libraryfolders.vdf"), []byte("\"libraryfolders\"\n{\n\t\"0\"\n\t{\n\t\t\"path\"\t\t\"C:\\\\Program Files (x86)\\\\Steam\"\n\t}\n\t\"1\"\n\t{\n\t\t\"path\"\t\t\"D:\\\\SteamLibrary\"\n\t}\n}\n"), 0644)
	l := steamLibraryFolders(s)
	if len(l) != 3 || !bytes.Contains([]byte(l[2]), []byte(`D:\SteamLibrary`)) {
		t.Fatal(l)
	}
}

func TestInstallUpdateRemove(t *testing.T) {
	g := fakeGame(t)
	f := edition.Folder + "/"
	p := mkzip(t, map[string]string{f + "Hydro.exe": "v1", f + "settings.txt": "default", f + "mods/hydro/a.json": "a", "other/x": "no"})
	files, err := installFiles(p, g, nil)
	if err != nil || len(files) != 2 {
		t.Fatal(err, files)
	}
	dir := filepath.Join(g, edition.Folder)
	os.WriteFile(filepath.Join(dir, uninstallExe), []byte("u"), 0755)
	writeManifest(dir, files)
	os.WriteFile(filepath.Join(dir, "settings.txt"), []byte("mine"), 0644)
	os.MkdirAll(filepath.Join(dir, "saves"), 0755)
	os.WriteFile(filepath.Join(dir, "saves", "Game 1.rcp"), []byte("s"), 0644)
	// update keeps the player's settings
	p2 := mkzip(t, map[string]string{f + "Hydro.exe": "v2", f + "settings.txt": "default", f + "mods/hydro/a.json": "a2"})
	if _, err := installFiles(p2, g, nil); err != nil {
		t.Fatal(err)
	}
	if b, _ := os.ReadFile(filepath.Join(dir, "settings.txt")); string(b) != "mine" {
		t.Fatal("settings overwritten")
	}
	if b, _ := os.ReadFile(filepath.Join(dir, "Hydro.exe")); string(b) != "v2" {
		t.Fatal("not updated")
	}
	if _, err := os.Stat(filepath.Join(g, "other")); err == nil {
		t.Fatal("outside")
	}
	// remove keeps saves and settings
	if failed := removeFiles(dir, false); len(failed) != 0 {
		t.Fatal(failed)
	}
	if _, err := os.Stat(filepath.Join(dir, "Hydro.exe")); err == nil {
		t.Fatal("not removed")
	}
	if _, err := os.Stat(filepath.Join(dir, "mods")); err == nil {
		t.Fatal("empty dir left")
	}
	if _, err := os.Stat(filepath.Join(dir, "saves", "Game 1.rcp")); err != nil {
		t.Fatal("save removed")
	}
	removeFiles(dir, true)
	if _, err := os.Stat(filepath.Join(dir, "saves")); err == nil {
		t.Fatal("saves kept")
	}
	if _, err := os.Stat(filepath.Join(g, "data", "menus.wad")); err != nil {
		t.Fatal("game touched")
	}
}
