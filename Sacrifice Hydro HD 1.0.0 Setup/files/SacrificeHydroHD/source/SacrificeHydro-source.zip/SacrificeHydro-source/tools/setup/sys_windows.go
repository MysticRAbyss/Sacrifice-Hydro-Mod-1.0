//go:build windows

package main

// Windows parts of the setup: where Sacrifice is installed (GOG / Steam registry entries), the
// Apps & features entry, shortcuts, the Visual C++ runtime check and administrator rights.

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"

	"github.com/lxn/win"
	"golang.org/x/sys/windows/registry"
)

const createNoWindow = 0x08000000

func regString(root registry.Key, path, name string) string {
	k, err := registry.OpenKey(root, path, registry.QUERY_VALUE|registry.WOW64_32KEY)
	if err != nil {
		k, err = registry.OpenKey(root, path, registry.QUERY_VALUE)
		if err != nil {
			return ""
		}
	}
	defer k.Close()
	s, _, err := k.GetStringValue(name)
	if err != nil {
		return ""
	}
	return s
}

// subKeys lists the sub keys of path (32- and 64-bit views)
func subKeys(root registry.Key, path string) []string {
	var r []string
	for _, view := range []uint32{registry.WOW64_32KEY, registry.WOW64_64KEY} {
		k, err := registry.OpenKey(root, path, registry.ENUMERATE_SUB_KEYS|view)
		if err != nil {
			continue
		}
		names, _ := k.ReadSubKeyNames(-1)
		k.Close()
		r = append(r, names...)
	}
	return r
}

// registryGameFolders: GOG's game entries, the uninstall entries (GOG, Steam, CD) and Steam's libraries
func registryGameFolders() []string {
	var l []string
	for _, root := range []registry.Key{registry.LOCAL_MACHINE, registry.CURRENT_USER} {
		for _, id := range subKeys(root, `SOFTWARE\GOG.com\Games`) {
			p := `SOFTWARE\GOG.com\Games\` + id
			if strings.Contains(strings.ToLower(regString(root, p, "gameName")), "sacrifice") {
				l = append(l, regString(root, p, "path"))
			}
		}
		un := `SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall`
		for _, id := range subKeys(root, un) {
			p := un + `\` + id
			name := strings.ToLower(regString(root, p, "DisplayName"))
			if strings.Contains(name, "sacrifice") && !strings.Contains(name, "hydro") {
				l = append(l, regString(root, p, "InstallLocation"))
			}
		}
	}
	l = append(l, steamLibraryFolders(regString(registry.CURRENT_USER, `Software\Valve\Steam`, "SteamPath"))...)
	l = append(l, steamLibraryFolders(regString(registry.LOCAL_MACHINE, `SOFTWARE\Valve\Steam`, "InstallPath"))...)
	return l
}

func fixedDrives() []string {
	var d []string
	for c := 'C'; c <= 'Z'; c++ {
		if _, err := os.Stat(string(c) + `:\`); err == nil {
			d = append(d, string(c))
		}
	}
	return d
}

// guessGameFolder: next to the setup first (it may have been put into the Sacrifice folder), then
// the registry, then the usual folders
func guessGameFolder() string {
	exe, _ := os.Executable()
	c := []string{filepath.Dir(exe)}
	c = append(c, registryGameFolders()...)
	c = append(c, commonGameFolders(fixedDrives())...)
	return findGameFolder(c)
}

func hasVCRuntime() bool {
	sys := os.Getenv("SystemRoot")
	if sys == "" {
		sys = `C:\Windows`
	}
	_, err := os.Stat(filepath.Join(sys, "System32", "vcruntime140.dll"))
	return err == nil
}

const vcRedistURL = "https://aka.ms/vs/17/release/vc_redist.x64.exe"

func openURL(u string) {
	win.ShellExecute(0, syscall.StringToUTF16Ptr("open"), syscall.StringToUTF16Ptr(u), nil, nil, win.SW_SHOWNORMAL)
}

func openFolder(p string) {
	win.ShellExecute(0, syscall.StringToUTF16Ptr("open"), syscall.StringToUTF16Ptr(p), nil, nil, win.SW_SHOWNORMAL)
}

// runElevated starts this program again with administrator rights
func runElevated(args string) bool {
	exe, _ := os.Executable()
	return win.ShellExecute(0, syscall.StringToUTF16Ptr("runas"), syscall.StringToUTF16Ptr(exe), syscall.StringToUTF16Ptr(args), nil, win.SW_SHOWNORMAL)
}

// canWrite tells whether files can be created in folder
func canWrite(folder string) bool {
	f, err := os.CreateTemp(folder, ".hydro-setup-*")
	if err != nil {
		return false
	}
	name := f.Name()
	f.Close()
	os.Remove(name)
	return true
}

func powershell(script string) error {
	cmd := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script)
	cmd.SysProcAttr = &syscall.SysProcAttr{CreationFlags: createNoWindow}
	return cmd.Run()
}

func psQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }

// startMenuFolder is the folder of the shortcuts in the Start menu (for this user)
func startMenuFolder() string {
	return filepath.Join(os.Getenv("APPDATA"), `Microsoft\Windows\Start Menu\Programs`, edition.Title)
}

// makeShortcuts creates the Desktop and Start menu shortcuts to the launcher (and the uninstaller)
func makeShortcuts(installDir string, desktop, startMenu bool) error {
	target := filepath.Join(installDir, launcherExe)
	var ps []string
	ps = append(ps, `$sh = New-Object -ComObject WScript.Shell`,
		`function mk($lnk, $target, $dir) { $s = $sh.CreateShortcut($lnk); $s.TargetPath = $target; $s.WorkingDirectory = $dir; $s.IconLocation = $target + ',0'; $s.Save() }`)
	if desktop {
		ps = append(ps, `mk ([IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), `+psQuote(edition.Title+".lnk")+`)) `+psQuote(target)+` `+psQuote(installDir))
	}
	if startMenu {
		sm := startMenuFolder()
		os.MkdirAll(sm, 0755)
		ps = append(ps, `mk `+psQuote(filepath.Join(sm, edition.Title+".lnk"))+` `+psQuote(target)+` `+psQuote(installDir))
		ps = append(ps, `mk `+psQuote(filepath.Join(sm, "Uninstall "+edition.Title+".lnk"))+` `+psQuote(filepath.Join(installDir, uninstallExe))+` `+psQuote(installDir))
	}
	if len(ps) == 2 {
		return nil
	}
	return powershell(strings.Join(ps, "; "))
}

func removeShortcuts() {
	os.RemoveAll(startMenuFolder())
	powershell(`Remove-Item -LiteralPath ([IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), ` + psQuote(edition.Title+".lnk") + `)) -ErrorAction SilentlyContinue`)
}

const uninstallKey = `Software\Microsoft\Windows\CurrentVersion\Uninstall\`

// register adds the mod to Windows' "Apps & features" (for this user)
func register(installDir string) error {
	k, _, err := registry.CreateKey(registry.CURRENT_USER, uninstallKey+edition.ID, registry.SET_VALUE)
	if err != nil {
		return err
	}
	defer k.Close()
	un := filepath.Join(installDir, uninstallExe)
	k.SetStringValue("DisplayName", edition.Title)
	k.SetStringValue("DisplayVersion", edition.Version)
	k.SetStringValue("Publisher", "Sacrifice: Hydro mod")
	k.SetStringValue("InstallLocation", installDir)
	k.SetStringValue("DisplayIcon", filepath.Join(installDir, launcherExe))
	k.SetStringValue("UninstallString", `"`+un+`"`)
	k.SetDWordValue("NoModify", 1)
	k.SetDWordValue("NoRepair", 1)
	if edition.Size > 0 {
		k.SetDWordValue("EstimatedSize", uint32(edition.Size))
	}
	return nil
}

func unregister() {
	registry.DeleteKey(registry.CURRENT_USER, uninstallKey+edition.ID)
}

// deleteLater removes the uninstaller (and the folder, if empty) once it has exited
func deleteLater(installDir string) {
	exe, _ := os.Executable()
	script := `ping -n 3 127.0.0.1 > nul & del /f /q "` + exe + `" & rmdir "` + installDir + `"`
	cmd := exec.Command("cmd.exe", "/c", script)
	cmd.SysProcAttr = &syscall.SysProcAttr{CreationFlags: createNoWindow, CmdLine: `cmd.exe /c "` + script + `"`}
	cmd.Start()
}

// processRunning tells whether a program from installDir is still running (the game or the launcher)
func processRunning(installDir string) bool {
	for _, n := range []string{"Hydro.exe", launcherExe} {
		p := filepath.Join(installDir, n)
		if _, err := os.Stat(p); err != nil {
			continue
		}
		// a running exe cannot be renamed
		if err := os.Rename(p, p+".check"); err != nil {
			return true
		}
		os.Rename(p+".check", p)
	}
	return false
}
