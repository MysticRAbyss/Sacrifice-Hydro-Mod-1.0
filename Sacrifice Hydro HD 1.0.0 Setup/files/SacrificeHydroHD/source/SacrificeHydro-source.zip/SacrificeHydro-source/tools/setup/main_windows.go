//go:build windows

package main

// Sacrifice: Hydro setup (and, built without the package, its uninstaller)

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
)

func main() {
	if isUninstaller {
		runUninstaller()
		return
	}
	runSetup()
}

func argValue(name string) (string, bool) {
	for _, a := range os.Args[1:] {
		if strings.HasPrefix(a, name+"=") {
			return strings.Trim(a[len(name)+1:], `"`), true
		}
		if a == name {
			return "", true
		}
	}
	return "", false
}

func runSetup() {
	title := edition.Title + " " + edition.Version + " Setup"
	folder, given := argValue("--dir")
	if !given {
		folder = guessGameFolder()
	}
	_, autoInstall := argValue("--install")

	var mw *walk.MainWindow
	var folderEdit *walk.LineEdit
	var check, target *walk.Label
	var desktop, startMenu *walk.CheckBox
	var progress *walk.ProgressBar
	var installBtn, cancelBtn, browseBtn *walk.PushButton
	installed := ""

	validate := func() bool {
		f := normalizeGameFolder(folderEdit.Text())
		if f == "" {
			missing := missingGameFiles(strings.TrimSpace(folderEdit.Text()))
			if strings.TrimSpace(folderEdit.Text()) == "" {
				check.SetText("Choose the folder where Sacrifice is installed (it has the \"data\" and \"maps\" folders).")
			} else {
				check.SetText("This is not a Sacrifice folder. Missing: " + strings.Join(missing, ", "))
			}
			target.SetText("")
			installBtn.SetEnabled(false)
			return false
		}
		check.SetText("Sacrifice found.")
		target.SetText("The mod goes into: " + filepath.Join(f, edition.Folder))
		installBtn.SetEnabled(true)
		return true
	}

	finish := func(dir string) {
		installed = dir
		check.SetText(edition.Title + " is installed. Start it with \"" + edition.Title + "\" on the Desktop or in the Start menu, or with \"" + launcherExe + "\" in its folder.")
		target.SetText(dir)
		installBtn.SetText("Play now")
		installBtn.SetEnabled(true)
		cancelBtn.SetText("Close")
		cancelBtn.SetEnabled(true)
	}

	install := func() {
		if installed != "" { // "Play now"
			cmd := exec.Command(filepath.Join(installed, launcherExe))
			cmd.Dir = installed
			cmd.Start()
			mw.Close()
			return
		}
		if !validate() {
			return
		}
		game := normalizeGameFolder(folderEdit.Text())
		dir := filepath.Join(game, edition.Folder)
		if processRunning(dir) {
			walk.MsgBox(mw, title, "Please close the game and its launcher first.", walk.MsgBoxIconInformation)
			return
		}
		if !canWrite(game) {
			if walk.MsgBox(mw, title, "Windows needs administrator rights to put files into\r\n"+game+".\r\n\r\nContinue as administrator?", walk.MsgBoxYesNo|walk.MsgBoxIconQuestion) == walk.DlgCmdYes {
				if runElevated(fmt.Sprintf(`--dir="%s" --install`, game)) {
					mw.Close()
				}
			}
			return
		}
		wantDesktop, wantStart := desktop.Checked(), startMenu.Checked()
		installBtn.SetEnabled(false)
		cancelBtn.SetEnabled(false)
		browseBtn.SetEnabled(false)
		folderEdit.SetReadOnly(true)
		check.SetText("Installing...")
		go func() {
			files, err := installFiles(payload, game, func(done, total int) {
				mw.Synchronize(func() { progress.SetRange(0, total); progress.SetValue(done) })
			})
			if err == nil {
				err = os.WriteFile(filepath.Join(dir, uninstallExe), uninstallerBin, 0755)
			}
			if err == nil {
				err = writeManifest(dir, files)
			}
			var warn []string
			if err == nil {
				if e := register(dir); e != nil {
					warn = append(warn, "It could not be added to Apps & features ("+e.Error()+"); to remove it, run Uninstall.exe in its folder.")
				}
				if e := makeShortcuts(dir, wantDesktop, wantStart); e != nil {
					warn = append(warn, "The shortcuts could not be made ("+e.Error()+"); start "+launcherExe+" in its folder.")
				}
			}
			mw.Synchronize(func() {
				if err != nil {
					walk.MsgBox(mw, title, "The installation did not finish:\r\n"+err.Error(), walk.MsgBoxIconError)
					check.SetText("The installation did not finish.")
					installBtn.SetEnabled(true)
					cancelBtn.SetEnabled(true)
					browseBtn.SetEnabled(true)
					folderEdit.SetReadOnly(false)
					return
				}
				if len(warn) > 0 {
					walk.MsgBox(mw, title, strings.Join(warn, "\r\n\r\n"), walk.MsgBoxIconWarning)
				}
				finish(dir)
			})
		}()
	}

	intro := "This puts " + edition.Title + " into your Sacrifice folder.\r\n\r\n" +
		"It needs the original Sacrifice (GOG or Steam version). None of the game's files come with the mod: " +
		"it uses the ones of your copy, and does not change them."
	if strings.Contains(edition.ID, "HD") {
		intro += "\r\n\r\nThe high-resolution textures are made from your copy of the game the first time you press Play (a few minutes, once)."
	}
	vc := hasVCRuntime()

	err := MainWindow{
		AssignTo: &mw,
		Title:    title,
		MinSize:  Size{Width: 560, Height: 430},
		Size:     Size{Width: 600, Height: 460},
		Layout:   VBox{Margins: Margins{Left: 16, Top: 14, Right: 16, Bottom: 14}},
		Children: []Widget{
			Label{Text: edition.Title + " " + edition.Version, Font: Font{PointSize: 15, Bold: true}},
			Label{Text: intro},
			GroupBox{Title: "Sacrifice folder", Layout: HBox{}, Children: []Widget{
				LineEdit{AssignTo: &folderEdit, Text: folder, OnTextChanged: func() { validate() }},
				PushButton{AssignTo: &browseBtn, Text: "Browse...", OnClicked: func() {
					dlg := walk.FileDialog{Title: "Choose the Sacrifice folder (the one with the \"data\" and \"maps\" folders)", InitialDirPath: folderEdit.Text()}
					if ok, _ := dlg.ShowBrowseFolder(mw); ok {
						if f := normalizeGameFolder(dlg.FilePath); f != "" {
							folderEdit.SetText(f)
						} else {
							folderEdit.SetText(dlg.FilePath)
						}
					}
				}},
			}},
			Label{AssignTo: &check, Text: ""},
			Label{AssignTo: &target, Text: ""},
			CheckBox{AssignTo: &desktop, Text: "Shortcut on the Desktop", Checked: true},
			CheckBox{AssignTo: &startMenu, Text: "Shortcuts in the Start menu", Checked: true},
			Composite{Visible: !vc, Layout: HBox{MarginsZero: true}, Children: []Widget{
				Label{Text: "The game needs the Microsoft Visual C++ Redistributable (x64), which this PC does not have yet."},
				PushButton{Text: "Get it", OnClicked: func() { openURL(vcRedistURL) }},
			}},
			VSpacer{},
			ProgressBar{AssignTo: &progress},
			Composite{Layout: HBox{MarginsZero: true}, Children: []Widget{
				HSpacer{},
				PushButton{AssignTo: &installBtn, Text: "Install", MinSize: Size{Width: 110}, OnClicked: install},
				PushButton{AssignTo: &cancelBtn, Text: "Cancel", OnClicked: func() { mw.Close() }},
			}},
		},
	}.Create()
	if err != nil {
		walk.MsgBox(nil, title, err.Error(), walk.MsgBoxIconError)
		return
	}
	validate()
	if autoInstall {
		install()
	}
	mw.Run()
}

func runUninstaller() {
	title := "Uninstall " + edition.Title
	exe, _ := os.Executable()
	dir := filepath.Dir(exe)
	var dlg *walk.Dialog
	var all *walk.CheckBox
	remove := false
	everything := false
	_, err := Dialog{
		AssignTo: &dlg,
		Title:    title,
		MinSize:  Size{Width: 460, Height: 200},
		Layout:   VBox{Margins: Margins{Left: 14, Top: 12, Right: 14, Bottom: 12}},
		Children: []Widget{
			Label{Text: "Remove " + edition.Title + " from\r\n" + dir + "?\r\n\r\nYour Sacrifice game itself is not touched."},
			CheckBox{AssignTo: &all, Text: "Also delete my settings, key bindings and saved games"},
			VSpacer{},
			Composite{Layout: HBox{MarginsZero: true}, Children: []Widget{
				HSpacer{},
				PushButton{Text: "Remove", MinSize: Size{Width: 90}, OnClicked: func() { remove, everything = true, all.Checked(); dlg.Accept() }},
				PushButton{Text: "Cancel", OnClicked: func() { dlg.Cancel() }},
			}},
		},
	}.Run(nil)
	if err != nil || !remove {
		return
	}
	if processRunning(dir) {
		walk.MsgBox(nil, title, "Please close the game and its launcher first, then run the uninstaller again.", walk.MsgBoxIconInformation)
		return
	}
	failed := removeFiles(dir, everything)
	removeShortcuts()
	unregister()
	msg := edition.Title + " has been removed."
	if len(failed) > 0 {
		msg += "\r\n\r\nSome files could not be deleted (are they open?):\r\n" + strings.Join(failed, "\r\n")
	} else if !everything {
		msg += "\r\n\r\nYour settings and saved games are still in\r\n" + dir
	}
	walk.MsgBox(nil, title, msg, walk.MsgBoxIconInformation)
	deleteLater(dir)
}
