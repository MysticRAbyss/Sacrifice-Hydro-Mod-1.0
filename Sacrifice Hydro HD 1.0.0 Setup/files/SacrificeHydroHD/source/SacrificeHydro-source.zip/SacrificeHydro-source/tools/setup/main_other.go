//go:build !windows

package main

func main() {} // the setup is a Windows program; the shared parts are tested on other systems
