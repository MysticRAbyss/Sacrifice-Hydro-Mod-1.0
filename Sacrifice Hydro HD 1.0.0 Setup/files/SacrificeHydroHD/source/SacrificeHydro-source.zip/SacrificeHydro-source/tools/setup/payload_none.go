//go:build !payload

package main

// built without the package: this program is the uninstaller that the setup puts into the mod's folder
var payload []byte
var uninstallerBin []byte

const isUninstaller = true
