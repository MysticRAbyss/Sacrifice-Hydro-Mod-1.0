//go:build payload

package main

import _ "embed"

//go:embed payload.zip
var payload []byte

//go:embed uninstall.exe
var uninstallerBin []byte

const isUninstaller = false
