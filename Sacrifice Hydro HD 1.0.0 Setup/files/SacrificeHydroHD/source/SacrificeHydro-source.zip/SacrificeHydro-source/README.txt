Sacrifice: Hydro 1.0.0 - source code
====================================

This is the complete source of Sacrifice: Hydro (and Sacrifice Hydro HD), as the GPL-3.0 licence
of sacengine requires. None of Sacrifice's own files are included.

engine\                      sacengine (https://github.com/tg-2/sacengine) by tg and contributors,
                             with the Hydro changes (GPL-3.0). The Hydro code is mostly in
                             source\hydromod.d, source\hydrosave.d and marked "Hydro mod" elsewhere.
hydro-engine-changes.patch   all Hydro changes as one patch against sacengine commit 181d1ce.
hydro-dagon-changes.patch    the Hydro changes to dagon (tg's fork, engine\dagon) against commit 3ccbb7a.
tools\launcher\              the launcher (Go, lxn/walk).
tools\setup2\                the setup / uninstaller of Sacrifice HD, Sacrifice: Hydro and Sacrifice Hydro HD
                             (Go, lxn/walk, go-ole); editions\ holds each one's settings; "go test" runs its
                             tests. (tools\setup\ is the older one, no longer used.)
tools\verinfo\               writes the version information into the programs (uses goversioninfo, MIT).
tools\kappagen\              builds the Hydro creature models from the original creatures'
                             skeletons (reads your own Sacrifice data files).
tools\sfx\                   Python scripts for the icons, effects textures, manalith and sounds.
tools\release\               the README generator.

Building
- Engine: LDC 1.41 and dub. In engine\:
    dub build -b release-debug -c application-audioformats --arch=x86_64-windows-msvc
  produces 3d.exe (shipped as Hydro.exe).
- Launcher: in tools\launcher, with Go 1.24 (and rsrc for the icon and manifest):
    GOOS=windows GOARCH=amd64 go build -ldflags "-H windowsgui" -o "Sacrifice Hydro Launcher.exe" .
- Setups: tools\release\build-releases.sh builds all three downloads (setup next to a "files" folder).
